import React, { useState } from "react";
import { Camera, HelpCircle, ShoppingBag } from "lucide-react";

export default function PreviewEDukaan() {
  const [step, setStep] = useState(1);
  const [language, setLanguage] = useState("en");
  const [newProduct, setNewProduct] = useState("");
  const [storeData, setStoreData] = useState({
    phone: "",
    name: "",
    address: "",
    products: [],
  });

  const languages = [
    { code: "en", name: "English" },
    { code: "hi", name: "हिंदी" },
    { code: "bn", name: "বাংলা" },
    { code: "te", name: "తెలుగు" },
    { code: "ta", name: "தமிழ்" },
  ];

  const handleNextStep = () => setStep((prev) => Math.min(prev + 1, 4));
  const handlePreviousStep = () => setStep((prev) => Math.max(prev - 1, 1));

  const addProduct = () => {
    if (newProduct.trim()) {
      setStoreData((prev) => ({
        ...prev,
        products: [...prev.products, newProduct.trim()],
      }));
      setNewProduct("");
    }
  };

  const removeProduct = (index) => {
    setStoreData((prev) => ({
      ...prev,
      products: prev.products.filter((_, i) => i !== index),
    }));
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="w-full bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-4">Basic Information</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  className="w-full p-2 border rounded-md"
                  placeholder="Enter your phone number"
                  value={storeData.phone}
                  onChange={(e) =>
                    setStoreData((prev) => ({ ...prev, phone: e.target.value }))
                  }
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Preferred Language
                </label>
                <select
                  className="w-full p-2 border rounded-md"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  {languages.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="w-full bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-4">Store Details</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Store Name
                </label>
                <input
                  type="text"
                  className="w-full p-2 border rounded-md"
                  placeholder="Enter your store name"
                  value={storeData.name}
                  onChange={(e) =>
                    setStoreData((prev) => ({ ...prev, name: e.target.value }))
                  }
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Store Address
                </label>
                <textarea
                  className="w-full p-2 border rounded-md"
                  placeholder="Enter your store address"
                  value={storeData.address}
                  onChange={(e) =>
                    setStoreData((prev) => ({
                      ...prev,
                      address: e.target.value,
                    }))
                  }
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="w-full bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-4">Add Products</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Product Name
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    className="flex-1 p-2 border rounded-md"
                    placeholder="Enter product name"
                    value={newProduct}
                    onChange={(e) => setNewProduct(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addProduct()}
                  />
                  <button
                    className="px-4 py-2 bg-blue-600 text-white rounded-md"
                    onClick={addProduct}
                  >
                    Add
                  </button>
                </div>
              </div>
              <div className="mt-4">
                <h3 className="font-medium mb-2">
                  Added Products ({storeData.products.length})
                </h3>
                <ul className="space-y-2">
                  {storeData.products.map((product, index) => (
                    <li
                      key={index}
                      className="flex items-center justify-between p-2 bg-gray-50 rounded"
                    >
                      <span>{product}</span>
                      <button
                        className="text-red-600 hover:text-red-800"
                        onClick={() => removeProduct(index)}
                      >
                        Remove
                      </button>
                    </li>
                  ))}
                  {storeData.products.length === 0 && (
                    <li className="text-gray-500 p-2">No products added yet</li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="w-full bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold mb-4">Preview & Launch</h2>
            <div className="space-y-6">
              <div>
                <h3 className="font-medium text-lg mb-2">Store Information</h3>
                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <p>
                    <span className="font-medium">Phone:</span>{" "}
                    {storeData.phone || "Not provided"}
                  </p>
                  <p>
                    <span className="font-medium">Language:</span>{" "}
                    {languages.find((l) => l.code === language)?.name ||
                      "English"}
                  </p>
                  <p>
                    <span className="font-medium">Store Name:</span>{" "}
                    {storeData.name || "Not provided"}
                  </p>
                  <p>
                    <span className="font-medium">Address:</span>{" "}
                    {storeData.address || "Not provided"}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-medium text-lg mb-2">
                  Products ({storeData.products.length})
                </h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  {storeData.products.length > 0 ? (
                    <ul className="space-y-2">
                      {storeData.products.map((product, index) => (
                        <li
                          key={index}
                          className="p-2 bg-white rounded shadow-sm"
                        >
                          {product}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500">No products added yet</p>
                  )}
                </div>
              </div>

              <button className="w-full py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                Launch Store
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-gray-50 p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">E-Dukaan Setup</h1>
          <div className="flex gap-2">
            <ShoppingBag className="text-blue-600" size={24} />
            <Camera className="text-gray-400" size={24} />
            <HelpCircle className="text-gray-400" size={24} />
          </div>
        </div>

        <div className="flex items-center justify-between mb-8">
          {[1, 2, 3, 4].map((number) => (
            <div className="flex items-center" key={number}>
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= number
                    ? "bg-blue-600 text-white"
                    : "bg-gray-200 text-gray-600"
                }`}
              >
                {number}
              </div>
              {number !== 4 && (
                <div
                  className={`flex-1 h-1 mx-2 ${
                    step > number ? "bg-blue-600" : "bg-gray-200"
                  }`}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {renderStepContent()}

      <div className="mt-6 flex justify-between">
        <button
          className={`px-6 py-2 rounded-md transition-colors ${
            step === 1
              ? "bg-gray-100 text-gray-400 cursor-not-allowed"
              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
          onClick={handlePreviousStep}
          disabled={step === 1}
        >
          Previous
        </button>
        <button
          className={`px-6 py-2 rounded-md transition-colors ${
            step === 4
              ? "bg-gray-100 text-gray-400 cursor-not-allowed"
              : "bg-blue-600 text-white hover:bg-blue-700"
          }`}
          onClick={handleNextStep}
          disabled={step === 4}
        >
          Next
        </button>
      </div>
    </div>
  );
}
